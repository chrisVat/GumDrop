These are the base Networks that will be finetuned: 
Resnet32 is 92.6% accuracy. 
Resnet110 is 93.79% accuracy. 